
public class BlackjackSolitaireRunner {
	
	public static void main(String[] args) {
		BlackJackSolitare bjs = new BlackJackSolitare();
		bjs.play();
	}
}
